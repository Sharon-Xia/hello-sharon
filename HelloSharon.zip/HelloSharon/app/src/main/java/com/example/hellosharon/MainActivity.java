package com.example.hellosharon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        findViewById(R.id.button).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                ((TextView) findViewById(R.id.textView)).setTextColor(
                        getResources().getColor(R.color.colorPrimary));
            }
        });

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                findViewById(R.id.Hello).setBackgroundColor(
                        getResources().getColor(R.color.babyblue));
            }
        });

        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newText = ((EditText) findViewById(R.id.editText)).getText().toString();
                if (TextUtils.isEmpty(newText))
                    ((TextView) findViewById(R.id.textView)).setText("Hello from Sharon!");
                else
                    ((TextView) findViewById(R.id.textView)).setText(newText);
            }
        });

        findViewById(R.id.Hello).setOnClickListener(new View.OnClickListener() { //reset all
            @Override
            public void onClick(View v) {
                // reset text color
                ((TextView) findViewById(R.id.textView)).setTextColor(
                        getResources().getColor(R.color.black));
                // reset bg color
                findViewById(R.id.Hello).setBackgroundColor(
                        getResources().getColor(R.color.colorAccent));
                // reset text
                ((TextView) findViewById(R.id.textView)).setText("Hello from Sharon!");

            }
        });
    }
}
